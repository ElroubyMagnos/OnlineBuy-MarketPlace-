window.onload = () =>
{
    document.getElementById('buffering').style.display = 'none';
}